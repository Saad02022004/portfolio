import React from 'react'
import Hero from './components/Hero'
import Projects from './components/Projects'
import Certifications from './components/Certifications'
import Skills from './components/Skills'
import About from './components/About'
import Education from './components/Education'
import Hobbies from './components/Hobbies'

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black text-white font-sans">
      <Hero />
      <main className="max-w-5xl mx-auto p-6 space-y-16">
        <Projects />
        <Certifications />
        <Skills />
        <About />
        <Education />
        <Hobbies />
      </main>
      <footer className="text-center p-6 text-gray-400">
        © {new Date().getFullYear()} Mohammed Saad Shaikh
      </footer>
    </div>
  )
}