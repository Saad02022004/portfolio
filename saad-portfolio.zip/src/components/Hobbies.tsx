import React from 'react'

export default function Hobbies() {
  return (
    <section id="hobbies">
      <h2 className="text-3xl font-semibold text-cyan-400 mb-4">Hobbies & Extra Activities</h2>
      <p className="text-gray-300">
        Participated in Hackathons, State-level Cricket Player, Awarded 'Man of the Series', 
        Enthusiastic about Robotics, IoT, and Innovation.
      </p>
    </section>
  )
}