import React from 'react'

export default function Skills() {
  return (
    <section id="skills">
      <h2 className="text-3xl font-semibold text-cyan-400 mb-4">Skills</h2>
      <p className="text-gray-300">
        C, C++, Embedded C, Python, MySQL, Arduino Uno, Raspberry Pi, Embedded Systems, MATLAB, Keil uVision, VS Code,
        Communication Skills, Problem Solving, Teamwork
      </p>
    </section>
  )
}