import React from 'react'

export default function About() {
  return (
    <section id="about">
      <h2 className="text-3xl font-semibold text-cyan-400 mb-4">About Me</h2>
      <p className="text-gray-300 leading-relaxed">
        I am Mohammed Saad Shaikh, pursuing B.Tech in Electronics and Telecommunication Engineering from 
        N.K. Orchid College of Engineering and Technology, Solapur, with a CGPA of 7.2. 
        I have strong skills in C, C++, Python, and MySQL, and hands-on experience with MATLAB, Keil uVision, and VS Code. 
        I am passionate about technology, innovation, and solving real-world problems through coding and embedded systems.
      </p>
    </section>
  )
}