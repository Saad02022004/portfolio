import React from 'react'

export default function Education() {
  return (
    <section id="education">
      <h2 className="text-3xl font-semibold text-cyan-400 mb-4">Education</h2>
      <ul className="list-disc ml-6 text-gray-300">
        <li>B.Tech in Electronics and Telecommunication Engineering — Orchid College, Solapur</li>
        <li>Higher Secondary Education — S.S.A High School & Junior College of Science, Solapur</li>
        <li>Secondary Education — Saint Joseph High School, Solapur</li>
      </ul>
    </section>
  )
}