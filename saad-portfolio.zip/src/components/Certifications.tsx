import React from 'react'

export default function Certifications() {
  return (
    <section id="certifications">
      <h2 className="text-3xl font-semibold text-cyan-400 mb-4">Certifications</h2>
      <ul className="list-disc ml-6 text-gray-300">
        <li>Zensar Skill and Employability Training Program</li>
        <li>C and C++ Programming Course</li>
        <li>Arduino Uno Workshops</li>
        <li>Smart India Hackathon Participation</li>
      </ul>
    </section>
  )
}