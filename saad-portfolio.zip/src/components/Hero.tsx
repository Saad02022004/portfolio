import React from 'react'

export default function Hero() {
  return (
    <header className="p-6 text-center">
      <h1 className="text-4xl md:text-6xl font-bold">Mohammed Saad Sarfaraz Shaikh</h1>
      <p className="mt-3 text-lg text-gray-300">
        Aspiring Software Developer | Embedded Systems Engineer | Data Analyst
      </p>
      <div className="mt-6 flex justify-center gap-4">
        <a href="https://linkedin.com" target="_blank" className="text-cyan-400">LinkedIn</a>
        <a href="https://github.com" target="_blank" className="text-cyan-400">GitHub</a>
        <a href="https://instagram.com" target="_blank" className="text-cyan-400">Instagram</a>
        <a href="mailto:youremail@example.com" className="text-cyan-400">Email</a>
        <a href="tel:+91XXXXXXXXXX" className="text-cyan-400">Phone</a>
      </div>
    </header>
  )
}