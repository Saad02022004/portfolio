import React from 'react'

export default function Projects() {
  return (
    <section id="projects">
      <h2 className="text-3xl font-semibold text-cyan-400 mb-4">Projects</h2>
      <div className="space-y-4">
        <div>
          <h3 className="text-xl font-semibold">Smart Air Quality Monitoring System</h3>
          <p className="text-gray-300">
            IoT-based system with wireless sensors monitoring pollutants (PM2.5, PM10, VOCs, CO, CO₂, NO₂, SO₂, O₃) in real-time.
          </p>
        </div>
        <div>
          <h3 className="text-xl font-semibold">IoT-Based Air Quality Tracker</h3>
          <p className="text-gray-300">
            Real-time IoT-enabled monitoring system for CO, CO₂, and PM10 with online data visualization.
          </p>
        </div>
      </div>
    </section>
  )
}