# Mohammed Saad Shaikh — Portfolio Website

A modern, responsive developer portfolio built using **React + TypeScript + Vite + TailwindCSS** and deployed on **Vercel**.
This project showcases my projects, skills, certifications, and achievements in one place.

Follow the README for instructions on editing and deploying.
